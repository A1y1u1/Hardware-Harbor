<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Singlepro Entity
 *
 * @property int $id
 * @property string $type
 * @property string $subtype
 * @property string $descriptionimg
 * @property string $proname
 * @property string $catno
 * @property string $size
 * @property string $material
 * @property string $mount
 * @property string $Qtyperbox
 * @property string $perbox
 */
class Singlepro extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected $_accessible = [
        'type' => true,
        'subtype' => true,
        'descriptionimg' => true,
        'proname' => true,
        'catno' => true,
        'size' => true,
        'material' => true,
        'mount' => true,
        'Qtyperbox' => true,
        'perbox' => true,
    ];
}
