<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Product Model
 *
 * @method \App\Model\Entity\Product newEmptyEntity()
 * @method \App\Model\Entity\Product newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Product[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Product get($primaryKey, $options = [])
 * @method \App\Model\Entity\Product findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Product patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Product[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Product|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Product saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 */
class ProductTable extends Table
{
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->hasMany('Carts',[
            'foreignKey' => 'product_id', // Foreign key in the Carts table
        
        ]);

        
    }

    

    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->scalar('type')
            ->maxLength('type', 200)
            ->requirePresence('type', 'create')
            ->notEmptyString('type');

        $validator
            ->scalar('subtype')
            ->maxLength('subtype', 200)
            ->requirePresence('subtype', 'create')
            ->notEmptyString('subtype');

        $validator
            ->scalar('tilesimage')
            ->maxLength('tilesimage', 200)
            ->requirePresence('tilesimage', 'create')
            ->notEmptyFile('tilesimage');

        $validator
            ->scalar('descriptionimage')
            ->maxLength('descriptionimage', 200)
            ->requirePresence('descriptionimage', 'create')
            ->notEmptyFile('descriptionimage');

        $validator
            ->scalar('proname')
            ->maxLength('proname', 200)
            ->requirePresence('proname', 'create')
            ->notEmptyString('proname');

        $validator
            ->scalar('description')
            ->maxLength('description', 200)
            ->requirePresence('description', 'create')
            ->notEmptyString('description');

        $validator
            ->scalar('material')
            ->maxLength('material', 200)
            ->requirePresence('material', 'create')
            ->notEmptyString('material');

        $validator
            ->scalar('application')
            ->maxLength('application', 200)
            ->requirePresence('application', 'create')
            ->notEmptyString('application');

        $validator
            ->scalar('size')
            ->maxLength('size', 200)
            ->requirePresence('size', 'create')
            ->notEmptyString('size');

        $validator
            ->scalar('color')
            ->maxLength('color', 200)
            ->requirePresence('color', 'create')
            ->notEmptyString('color');

        $validator
            ->scalar('Qtyperbox')
            ->maxLength('Qtyperbox', 200)
            ->requirePresence('Qtyperbox', 'create')
            ->notEmptyString('Qtyperbox');

        $validator
            ->scalar('Coveragearea')
            ->maxLength('Coveragearea', 200)
            ->requirePresence('Coveragearea', 'create')
            ->notEmptyString('Coveragearea');

        $validator
            ->scalar('perbox')
            ->maxLength('perbox', 200)
            ->requirePresence('perbox', 'create')
            ->notEmptyString('perbox');

        return $validator;
    }
}
