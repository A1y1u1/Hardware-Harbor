<?php
declare(strict_types=1);

namespace App\Controller;
use cake\Event\EventInterface;
use Cake\ORM\Query;

/**
 * Carts Controller
 *
 * @property \App\Model\Table\CartsTable $Carts
 * @method \App\Model\Entity\Cart[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class CartsController extends AppController
{
    public function beforeFilter(EventInterface $event)
    
    {
        $this->viewBuilder()->setLayout('home');
    }
    
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $carts = $this->paginate($this->Carts);

        $this->set(compact('carts'));
    }

    /**
     * View method
     *
     * @param string|null $id Cart id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    
    // public function view($cartId)
    // {
    //     $cart = $this->Carts->get($cartId, ['contain' => ['CartItems.Products']]);
    //     $this->set(compact('cart'));
    // }

    public function view($id = null)
    {
        $cart = $this->Carts->get($id, [
            'contain' => [''],
        ]);

        $this->set(compact('cart'));
    }
    public function cartadd()
    {

   //pr ($this->request->getdata());pr($this->Carts->newEmptyEntity());die;
       
       // $pri = $this->request->getdata('price');
       $qty = $this->request->getdata('quantity');
        $pri = floatval(str_replace('₹ ', '', $this->request->getdata('price')));
        $total = $qty * $pri;
        // pr($total) ;die;
        // pr($total);die;
        $cart = $this->Carts->newEmptyEntity();
        if ($this->request->is('post')) {

            $data = $this->request->getData();
            $data['total'] = $total; // Set the total value in the data array    
            

            $cart = $this->Carts->patchEntity($cart, $data, $this->request->getData());
            if ($this->Carts->save($cart)) {
                $this->Flash->success(__('The cart has been saved.'));

                return $this->redirect(['action' => 'cartdetail']);
            }
            $this->Flash->error(__('The cart could not be saved. Please, try again.'));
        }
        $this->set(compact('cart','total'));
    }


    public function cartdetail() 
    {
        $carts = $this->Carts->find('all', [
            'contain' => ['Product'],
        ])->toArray();
    
        $this->set(compact('carts'));
        
    }

    public function billdetail() 
    {
        $carts = $this->Carts->find('all', [
            'contain' => ['Product'],
        ])->toArray();
    
        $this->set(compact('carts'));
        
        
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        pr($this->request->getdata());die;
        $cart = $this->Carts->newEmptyEntity();
        if ($this->request->is('post')) {
            $cart = $this->Carts->patchEntity($cart, $this->request->getData());
            if ($this->Carts->save($cart)) {
                $this->Flash->success(__('The cart has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The cart could not be saved. Please, try again.'));
        }
        $this->set(compact('cart'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Cart id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $cart = $this->Carts->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $cart = $this->Carts->patchEntity($cart, $this->request->getData());
            if ($this->Carts->save($cart)) {
                $this->Flash->success(__('The cart has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The cart could not be saved. Please, try again.'));
        }
        $this->set(compact('cart'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Cart id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        // debug('here');
        $this->request->allowMethod(['get', 'delete']);
        $cart = $this->Carts->get($id);
        if ($this->Carts->delete($cart)) {
            $this->Flash->success(__('The cart has been deleted.'));
        } else {
            $this->Flash->error(__('The cart could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'cartdetail']);
    }

    
}
