<?php
declare(strict_types=1);

namespace App\Controller;
use cake\Event\EventInterface;

/**
 * Usertables Controller
 *
 * @property \App\Model\Table\UsertablesTable $Usertables
 * @method \App\Model\Entity\Usertable[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UsertablesController extends AppController
{
    public function beforeFilter(EventInterface $event)
    
    {
        $this->viewBuilder()->setLayout('home');
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $usertables = $this->paginate($this->Usertables);

        $this->set(compact('usertables'));
    }

    /**
     * View method
     *
     * @param string|null $id Usertable id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $usertable = $this->Usertables->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('usertable'));
    }



    public function submit()
{
    $this -> loadModel('Usertables');
    // $usertable = $this->Usertables->newEmptyEntity();

    // if ($this->request->is('post')) {
    //     $usertable = $this->Usertables->patchEntity($usertable, $this->request->getData());

    //     // Hardcoding the user_id is temporary and should be replaced with proper authentication logic
    //     $usertable->user_id = 1;

    //     if ($this->Usertables->save($usertable)) {
    //         $this->Flash->success(__('Your record has been saved.'));
    //         return $this->redirect(['action' => 'index']);
    //     }
    //     $this->Flash->error(__('Unable to save your record. Please check the form.'));
    // }

    // $this->set(compact('usertable'));
// pr($this->request->getdata());die;
if (
    $this->request->is('post')

){
$field1 =$this->request->getdata('firstname');
$field2 =$this->request->getdata('lastname');
$field3 =$this->request->getdata('companyname');
$field4 =$this->request->getdata('address');
$field5 =$this->request->getdata('state');
$field6 =$this->request->getdata('post');
$field7 =$this->request->getdata('email');
$field8 =$this->request->getdata('phonenumber');
$field9 =$this->request->getdata('country');
$field10 =$this->request->getdata('username');
$field11 =$this->request->getdata('password');


$dataArray=[
    'firstname'=>$field1,
    'lastname'=>$field2,
    'companyname'=>$field3,
    'address'=>$field4,
    'state'=>$field5,
    'post'=>$field6,
    'email'=>$field7,
    'phonenumber'=>$field8,
    'country'=>$field9,
    'username'=>$field10,
    'password'=>$field11,
];

}
$this->add();





}

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        // pr($this->request->getdata());die;
        $usertable = $this->Usertables->newEmptyEntity();
        if ($this->request->is('post')) {
            $usertable = $this->Usertables->patchEntity($usertable, $this->request->getData());
            if ($this->Usertables->save($usertable)) {
                $this->Flash->success(__('The usertable has been saved.'));
                $this->loadModel('Carts');

                // Delete all records from the Carts table
                $success = $this->Carts->deleteAll([]);

                return $this->redirect(['controller' => 'Pages', 'action' => 'thankyou']);
                
            }
            $this->Flash->error(__('The usertable could not be saved. Please, try again.'));
        }
        $this->set(compact('usertable'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Usertable id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $usertable = $this->Usertables->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $usertable = $this->Usertables->patchEntity($usertable, $this->request->getData());
            if ($this->Usertables->save($usertable)) {
                $this->Flash->success(__('The usertable has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The usertable could not be saved. Please, try again.'));
        }
        $this->set(compact('usertable'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Usertable id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $usertable = $this->Usertables->get($id);
        if ($this->Usertables->delete($usertable)) {
            $this->Flash->success(__('The usertable has been deleted.'));
        } else {
            $this->Flash->error(__('The usertable could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
