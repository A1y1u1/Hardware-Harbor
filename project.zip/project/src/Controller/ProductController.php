<?php
declare(strict_types=1);

namespace App\Controller;
use cake\Event\EventInterface;

/**
 * Product Controller
 *
 * @property \App\Model\Table\ProductTable $Product
 * @method \App\Model\Entity\Product[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class ProductController extends AppController
{
    public function beforeFilter(EventInterface $event)
    
    {
        $this->viewBuilder()->setLayout('home');
    }

    public function allpro(){
        $param1 = $this->request->getQuery('param1');
        $result = $this->Product->find()
                ->where(['subtype'=> $param1])
                ->all(); 
                //foreach ($result as $article) {
                  //  debug($article->subtype);
               // }
                    
               $this->set(compact('result'));
    }

    public function singleproduct($id = null)
    {
        $this->loadModel('Carts');
        $product = $this->Product->get($id, [
            'contain' => [],
        ]);

        $this->set(compact('product'));
    }
    
   
  
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $product = $this->paginate($this->Product);

        $this->set(compact('product'));
    }

    /**
     * View method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function  view($cartId){
        $product = $this->Product->get($id, [
            'contain' => [],
        ]);
        $cart = $this->Carts->get($cartId, [
            'contain' => ['Products'], // Specify the associated model
        ]);
    
        $products = $cart->products;
    
        $this->set(compact('product'));
    }
   
    
    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $product = $this->Product->newEmptyEntity();
        if ($this->request->is('post')) {
            $product = $this->Product->patchEntity($product, $this->request->getData());
            if ($this->Product->save($product)) {
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
        }
        $this->set(compact('product'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $product = $this->Product->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $product = $this->Product->patchEntity($product, $this->request->getData());
            if ($this->Product->save($product)) {
                $this->Flash->success(__('The product has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The product could not be saved. Please, try again.'));
        }
        $this->set(compact('product'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Product id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $product = $this->Product->get($id);
        if ($this->Product->delete($product)) {
            $this->Flash->success(__('The product has been deleted.'));
        } else {
            $this->Flash->error(__('The product could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
