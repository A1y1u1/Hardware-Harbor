<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SingleproFixture
 */
class SingleproFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'singlepro';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'type' => 'Lorem ipsum dolor sit amet',
                'subtype' => 'Lorem ipsum dolor sit amet',
                'descriptionimg' => 'Lorem ipsum dolor sit amet',
                'proname' => 'Lorem ipsum dolor sit amet',
                'catno' => 'Lorem ipsum dolor sit amet',
                'size' => 'Lorem ipsum dolor sit amet',
                'material' => 'Lorem ipsum dolor sit amet',
                'mount' => 'Lorem ipsum dolor sit amet',
                'Qtyperbox' => 'Lorem ipsum dolor sit amet',
                'perbox' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
