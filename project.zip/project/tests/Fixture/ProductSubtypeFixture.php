<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ProductSubtypeFixture
 */
class ProductSubtypeFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'product_subtype';
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'protype_id' => 1,
                'subtypename' => 'Lorem ipsum dolor sit amet',
            ],
        ];
        parent::init();
    }
}
