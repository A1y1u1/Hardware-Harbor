<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ProductSubtypeTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ProductSubtypeTable Test Case
 */
class ProductSubtypeTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\ProductSubtypeTable
     */
    protected $ProductSubtype;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.ProductSubtype',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('ProductSubtype') ? [] : ['className' => ProductSubtypeTable::class];
        $this->ProductSubtype = $this->getTableLocator()->get('ProductSubtype', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->ProductSubtype);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\ProductSubtypeTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
