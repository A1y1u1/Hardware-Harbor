<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\ProtypesTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\ProtypesTable Test Case
 */
class ProtypesTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\ProtypesTable
     */
    protected $Protypes;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Protypes',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Protypes') ? [] : ['className' => ProtypesTable::class];
        $this->Protypes = $this->getTableLocator()->get('Protypes', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Protypes);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\ProtypesTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
