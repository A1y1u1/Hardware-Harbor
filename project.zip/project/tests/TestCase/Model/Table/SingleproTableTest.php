<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SingleproTable;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SingleproTable Test Case
 */
class SingleproTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\SingleproTable
     */
    protected $Singlepro;

    /**
     * Fixtures
     *
     * @var array<string>
     */
    protected $fixtures = [
        'app.Singlepro',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    protected function setUp(): void
    {
        parent::setUp();
        $config = $this->getTableLocator()->exists('Singlepro') ? [] : ['className' => SingleproTable::class];
        $this->Singlepro = $this->getTableLocator()->get('Singlepro', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    protected function tearDown(): void
    {
        unset($this->Singlepro);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     * @uses \App\Model\Table\SingleproTable::validationDefault()
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
