<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Usertable $usertable
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Usertables'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="usertables form content">
            <?= $this->Form->create($usertable) ?>
            <fieldset>
                <legend><?= __('Add Usertable') ?></legend>
                <?php
                    echo $this->Form->control('username');
                    echo $this->Form->control('email');
                    echo $this->Form->control('phonenumber');
                    echo $this->Form->control('password');
                    echo $this->Form->control('country');
                    echo $this->Form->control('firstname');
                    echo $this->Form->control('lastname');
                    echo $this->Form->control('companyname');
                    echo $this->Form->control('address');
                    echo $this->Form->control('state');
                    echo $this->Form->control('post');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
