<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Usertable $usertable
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Usertable'), ['action' => 'edit', $usertable->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Usertable'), ['action' => 'delete', $usertable->id], ['confirm' => __('Are you sure you want to delete # {0}?', $usertable->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Usertables'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Usertable'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="usertables view content">
            <h3><?= h($usertable->username) ?></h3>
            <table>
                <tr>
                    <th><?= __('Username') ?></th>
                    <td><?= h($usertable->username) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email') ?></th>
                    <td><?= h($usertable->email) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phonenumber') ?></th>
                    <td><?= h($usertable->phonenumber) ?></td>
                </tr>
                <tr>
                    <th><?= __('Country') ?></th>
                    <td><?= h($usertable->country) ?></td>
                </tr>
                <tr>
                    <th><?= __('Firstname') ?></th>
                    <td><?= h($usertable->firstname) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname') ?></th>
                    <td><?= h($usertable->lastname) ?></td>
                </tr>
                <tr>
                    <th><?= __('Companyname') ?></th>
                    <td><?= h($usertable->companyname) ?></td>
                </tr>
                <tr>
                    <th><?= __('Address') ?></th>
                    <td><?= h($usertable->address) ?></td>
                </tr>
                <tr>
                    <th><?= __('State') ?></th>
                    <td><?= h($usertable->state) ?></td>
                </tr>
                <tr>
                    <th><?= __('Post') ?></th>
                    <td><?= h($usertable->post) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($usertable->id) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
