
    <div class="container-fluid px-5 py-1 mb-3">
        <div>
            <h1><b></b></h1>
        </div>

        <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-5">
          <?php 
          foreach ($result as $prod)
            {
              ?> 
          <div class="col-md-4">
            <a href="singleproduct/<?= $prod->id ?>" class="BWTNAME">
            <div class="card shadow-sm">
                <img src="../webroot/img/<?= $prod->subtype ?>/<?= ($prod->tilesimage) ?>" alt="">
              <div class="card-body">
                <h2><?= h($prod->proname) ?></h2>
                <p class="card-text"><?= h($prod->description) ?></p>
              </div>
            </div>
            </a>
          </div>
          

      <?php
      }
       ?>
    </div>
  </div>
