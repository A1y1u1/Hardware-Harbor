<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Product $product
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Product'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="product form content">
            <?= $this->Form->create($product) ?>
            <fieldset>
                <legend><?= __('Add Product') ?></legend>
                <?php
                    echo $this->Form->control('type');
                    echo $this->Form->control('subtype');
                    echo $this->Form->control('tilesimage');
                    echo $this->Form->control('descriptionimage');
                    echo $this->Form->control('proname');
                    echo $this->Form->control('description');
                    echo $this->Form->control('material');
                    echo $this->Form->control('application');
                    echo $this->Form->control('size');
                    echo $this->Form->control('color');
                    echo $this->Form->control('Qtyperbox');
                    echo $this->Form->control('Coveragearea');
                    echo $this->Form->control('perbox');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
