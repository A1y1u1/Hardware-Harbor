<?php
/**
 * @var \App\View\AppView $this
 * @var iterable<\App\Model\Entity\Product> $product
 */
?>
<div class="product index content">
    <?= $this->Html->link(__('New Product'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Product') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id') ?></th>
                    <th><?= $this->Paginator->sort('type') ?></th>
                    <th><?= $this->Paginator->sort('subtype') ?></th>
                    <th><?= $this->Paginator->sort('tilesimage') ?></th>
                    <th><?= $this->Paginator->sort('descriptionimage') ?></th>
                    <th><?= $this->Paginator->sort('proname') ?></th>
                    <th><?= $this->Paginator->sort('description') ?></th>
                    <th><?= $this->Paginator->sort('material') ?></th>
                    <th><?= $this->Paginator->sort('application') ?></th>
                    <th><?= $this->Paginator->sort('size') ?></th>
                    <th><?= $this->Paginator->sort('color') ?></th>
                    <th><?= $this->Paginator->sort('Qtyperbox') ?></th>
                    <th><?= $this->Paginator->sort('Coveragearea') ?></th>
                    <th><?= $this->Paginator->sort('perbox') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($product as $product): ?>
                <tr>
                    <td><?= $this->Number->format($product->id) ?></td>
                    <td><?= h($product->type) ?></td>
                    <td><?= h($product->subtype) ?></td>
                    <td><?= h($product->tilesimage) ?></td>
                    <td><?= h($product->descriptionimage) ?></td>
                    <td><?= h($product->proname) ?></td>
                    <td><?= h($product->description) ?></td>
                    <td><?= h($product->material) ?></td>
                    <td><?= h($product->application) ?></td>
                    <td><?= h($product->size) ?></td>
                    <td><?= h($product->color) ?></td>
                    <td><?= h($product->Qtyperbox) ?></td>
                    <td><?= h($product->Coveragearea) ?></td>
                    <td><?= h($product->perbox) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $product->id]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $product->id]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $product->id], ['confirm' => __('Are you sure you want to delete # {0}?', $product->id)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
