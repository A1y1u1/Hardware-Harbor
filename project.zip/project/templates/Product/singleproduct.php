<script>

function myFunction(){
var qty=document.getElementById('qty').value;
console.log(qty);
}

function sub() {
        var fs = parseInt(document.getElementById("FS").value);
        // Set a minimum value (e.g., 0)
        if (fs > 0) {
            fs--;
        }
        document.getElementById("FS").value = fs;
    }

    function add() {
        var fs = parseInt(document.getElementById("FS").value);
        // Set a maximum value (e.g., 600)
        if (fs < 600) {
            fs++;
        }
        document.getElementById("FS").value = fs;
    }

</script>
<div class="container-fluid">
<div class="container py-5">
  <div class="row">
    <div class="col-lg-7 ">
       <img src="../../webroot/img/<?= $product->subtype ?>/<?= $product->descriptionimage?>" class="img-fluid" width="100%" >
       <h3><?= h($product->proname) ?></h3>
    </div>
    
    <div class="col-lg-5 ">
      <div class="row ">
      <div class="col-lg-6 mt-1"><b>Material</b></div>
      <div class="col-lg-6 mt-1"><?= h($product->material) ?></div>
      </div>
      <div class="row ">
      <div class="col-lg-6 mt-1"><b>Application</b></div>
      <div class="col-lg-6 mt-1"><?= h($product->application) ?></div>
      </div>
      <div class="row ">
      <div class="col-lg-6 mt-1"><b>Size</b></div>
      <div class="col-lg-6 mt-1"><?= h($product->size) ?></div>
      </div>
      <div class="row ">
      <div class="col-lg-6 mt-1"><b>Color</b></div>
      <div class="col-lg-6 mt-1"><?= h($product->color) ?></div>
      </div>
      <div class="row ">
      <div class="col-lg-6 mt-1"><b>Qty. Per Box</b></div>
      <div class="col-lg-6 mt-1"><?= h($product->Qtyperbox) ?></div>
      </div>
      <div class="row ">
      <div class="col-lg-6 mt-1"><b>Coverage Area</b></div>
      <div class="col-lg-6 mt-1"><?= h($product->Coveragearea) ?></div>
      </div>
      <?php echo $this->Form->create(null, [
    'url' => [
        'controller' => 'Carts',
        'action' => 'cartadd'
    ]
]); ?>
           
                <?php
                  
                    echo $this->Form->hidden('product_id', ['value' => $product->id]); ?>
                    <div class="row ">
                      <div class="col-lg-6 mt-1">
                        <b>No. of Boxes</b>
                      </div>
                      
                      <div class="col-lg-6 mt-1">
                        <!-- <?php 
                        $options = ['1'=>'1','2'=>'2','3'=>'3','4'=>'4','5'=>'5','6'=>'6','7'=>'7','8'=>'8','9'=>'9','10'=>'10','11'=>'11','12'=>'12']; 
                        echo $this->Form->select('quantity',$options); ?> -->

                      <?php echo $this->Form->input('quantity', ['type' => 'number','min' => 0,'value' => 1,
                      'max' => 600]); ?>


          <!-- <div class="input-group number-spinner w-50">
          <span class="input-group-btn">
        <?= $this->Form->button(
            '-',
            ['class' => 'btn btn-default', 'type' => 'button', 'data-dir' => 'dwn', 'onclick' => 'sub()']
        ); ?>
    </span>
    <?= $this->Form->text(
        'txtFS',
        ['class' => 'form-control text-center', 'value' => '1', 'name' => 'txtFS', 'id' => 'FS', 'style' => 'width: 50%;']
    ); ?>
    <span class="input-group-btn">
        <?= $this->Form->button(
            '+',
            ['class' => 'btn btn-default', 'type' => 'button', 'data-dir' => 'up', 'onclick' => 'add()']
        ); ?>
    </span>
          </div> -->




                      </div>
      <div class="row ">
        <div class="col-lg-6 mt-1">
          <b>Per Box</b>
        </div>
        <div class="col-lg-6 mt-1">
        <?php echo $this->Form->hidden('price', ['value' => $product->perbox]);?> 
          <?= h($product->perbox) ?>
        </div>
      </div>
      
      <div class="d-grid gap-2">
        <?php 
         echo $this->Form->submit('Add to Cart', ['class' => 'btn btn-primary float-end mt-2', 'id' => 'PlaceOrder']); ?>
        <?= $this->Form->end() ?>
        
        <a href="Billing Order.html" id="button">
          <button type="button" class="btn btn-primary float-end mt-2" id="PlaceOrder">Buy Now</button>
        </a>
      </div>

    </div>
  </div>

<!-- Description section ------>
<div class="row py-5">
   <div class="col-sm-6">
    <center><h3>Feedback</h3></center>
    <!-- form ------------>
    <form>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">First Name</label>
      <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter your first name">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Last Name</label>
      <input type="text" class="form-control" id="exampleFormControlInput1" placeholder="Enter your Last name">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Email address</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Password</label>
      <input type="Password" class="form-control" id="exampleFormControlInput1"> 
      <div><span>We'll never share your password with anyone else.</span></div>
    </div>
    <div class="mb-3">
      <label for="exampleFormControlTextarea1" class="form-label">Comment</label>
      <textarea class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
    </div>
    <div class="mb-3 form-check">
      <input type="checkbox" class="form-check-input" id="exampleCheck1">
      <label class="form-check-label" for="exampleCheck1">Remember me </label>
    </div>
    <button type="submit" class="btn btn-primary" id="PlaceOrder">Submit</button>
   </div>
   </form>
   <!-- Rating & Reviews section -->
   <div class="col-sm-6">
    <center><h3>Rating & Reviews</h3></center>
    <div class="box-container">

      <!-- BOX-1 -->
      <div class="box">
        <!-- top -->
         <div class="box-top">
         <!-- profile -->
         <div class="profile">
          <!-- img -->
          <div class="profile-img">
            <img src="img/Icon/Ayush.jpg" class="profile-img">
          </div>
          <!-- name and username -->
          <div class="name-user">
            <strong>Asim Ahmed</strong>
            <span>@asim_ahmed</span>
          </div>
         </div>
           <!-- Reviews ---------------------->
           <div class="reviews">
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-half"></i>
           </div>
         </div>
          <!-- Comments ---------------------->
          <div class="client-comment">
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
              Autem, doloremque. Delectus eveniet fuga tenetur architecto porro deserunt itaque sapiente, 
              ullam exercitationem. 
              Ipsa vero quasi fugit aperiam tempora dolore sunt unde!
            </p>
          </div>
      </div>

      <!-- BOX-2 -->
      <div class="box">
        <!-- top -->
         <div class="box-top">
         <!-- profile -->
         <div class="profile">
          <!-- img -->
          <div >
            <img src="img/Icon/Ayush.jpg" class="profile-img">
          </div>
          <!-- name and username -->
          <div class="name-user">
            <strong>Mariam Jo</strong>
            <span>@mariam_jo</span>
          </div>
         </div>
           <!-- Reviews ---------------------->
           <div class="reviews">
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star"></i>
           </div>
         </div>
          <!-- Comments ---------------------->
          <div class="client-comment">
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
              Autem, doloremque. Delectus eveniet fuga tenetur architecto porro deserunt itaque sapiente, 
              ullam exercitationem. 
              Ipsa vero quasi fugit aperiam tempora dolore sunt unde!
            </p>
          </div>
      </div>

      <!-- BOX-3 -->
      <div class="box">
        <!-- top -->
         <div class="box-top">
         <!-- profile -->
         <div class="profile">
          <!-- img -->
          <div>
            <img src="img/Icon/Ayush.jpg" class="profile-img">
          </div>
          <!-- name and username -->
          <div class="name-user">
            <strong>Jecab Malto</strong>
            <span>@jecab_malto</span>
          </div>
         </div>
           <!-- Reviews ---------------------->
           <div class="reviews">
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star-fill"></i>
            <i class="bi bi-star"></i>
            <i class="bi bi-star"></i>
           </div>
         </div>
          <!-- Comments ---------------------->
          <div class="client-comment">
            <p>
              Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
              Autem, doloremque. Delectus eveniet fuga tenetur architecto porro deserunt itaque sapiente, 
              ullam exercitationem. 
              Ipsa vero quasi fugit aperiam tempora dolore sunt unde!
            </p>
          </div>
      </div>

    </div>
    
   </div>

  </div>




</div>

</div>
</div>

