<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Product $product
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Product'), ['action' => 'edit', $product->id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Product'), ['action' => 'delete', $product->id], ['confirm' => __('Are you sure you want to delete # {0}?', $product->id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Product'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Product'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
        <h2>Cart Products</h2>
<ul>
    <?php foreach ($products as $product): ?>
        <li><?= h($product->name) ?></li>
    <?php endforeach; ?>
</ul>
    </aside>
    <div class="column-responsive column-80">
        <div class="product view content">
            <h3><?= h($product->proname) ?></h3>
            <table>
                <tr>
                    <th><?= __('Type') ?></th>
                    <td><?= h($product->type) ?></td>
                </tr>
                <tr>
                    <th><?= __('Subtype') ?></th>
                    <td><?= h($product->subtype) ?></td>
                </tr>
                <tr>
                    <th><?= __('Tilesimage') ?></th>
                    <td><?= h($product->tilesimage) ?></td>
                </tr>
                <tr>
                    <th><?= __('Descriptionimage') ?></th>
                    <td><?= h($product->descriptionimage) ?></td>
                </tr>
                <tr>
                    <th><?= __('Proname') ?></th>
                    <td><?= h($product->proname) ?></td>
                </tr>
                <tr>
                    <th><?= __('Description') ?></th>
                    <td><?= h($product->description) ?></td>
                </tr>
                <tr>
                    <th><?= __('Material') ?></th>
                    <td><?= h($product->material) ?></td>
                </tr>
                <tr>
                    <th><?= __('Application') ?></th>
                    <td><?= h($product->application) ?></td>
                </tr>
                <tr>
                    <th><?= __('Size') ?></th>
                    <td><?= h($product->size) ?></td>
                </tr>
                <tr>
                    <th><?= __('Color') ?></th>
                    <td><?= h($product->color) ?></td>
                </tr>
                <tr>
                    <th><?= __('Qtyperbox') ?></th>
                    <td><?= h($product->Qtyperbox) ?></td>
                </tr>
                <tr>
                    <th><?= __('Coveragearea') ?></th>
                    <td><?= h($product->Coveragearea) ?></td>
                </tr>
                <tr>
                    <th><?= __('Perbox') ?></th>
                    <td><?= h($product->perbox) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id') ?></th>
                    <td><?= $this->Number->format($product->id) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
