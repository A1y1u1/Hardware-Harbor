 <nav style="--bs-breadcrumb-divider: url(&#34;data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='8'%3E%3Cpath d='M2.5 0L1 1.5 3.5 4 1 6.5 2.5 8l4-4-4-4z' fill='%236c757d'/%3E%3C/svg%3E&#34;);" aria-label="breadcrumb">
        <ol class="breadcrumb py-2" style="background-color: #E5E1DA;">
          <li class="breadcrumb-item"><a href="Header.html">Home</a></li>
          <li class="breadcrumb-item active" aria-current="page">About</li>
        </ol>
      </nav>
       
       
        <div class="container py-5">
            <div class="row" style="column-gap: 1px;">
                <div class="col-md-12 text-center">
                    <h5>FEEL COMFORTABLE</h5><br>
                    <h1><b>TILES FOR EVERY PURPOSE</b></h1>
                </div>
                <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
                  <div class="carousel-indicators">
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
                    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
                  </div>
                  <div class="carousel-inner">
                    <div class="carousel-item active">
                      <img src="../webroot/img/About.jpg" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img src="../webroot/img/About1.jpg" class="d-block w-100" alt="...">
                    </div>
                    <div class="carousel-item">
                      <img src="../webroot/img/About2.jpg" class="d-block w-100" alt="...">
                    </div>
                  </div>
                  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                  </button>
                  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                  </button>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h5>RESIDENTIAL & COMMERCIAL</h5><br>
                    <h1><b>TILE INSTALLATION SOLUTIONS</b></h1>
                </div>
                <div class="col-sm-3 text-center">
                    <img class="abi" src="../webroot/img/About img/Tiles Fixing.webp" alt="">
                    <h3 class="abouth3">Tiles Fixing</h3>
                    <p class="aboutp">Massa massa ultricies mi quis hendrer auctor tincidunt aliquam sit amet cursus mauris</p>
                </div>
                <div class="col-sm-3 text-center">
                    <img class="abi" src="../webroot/img/About img/Tile Installation.webp" alt="">
                    <h3 class="abouth3">Tile Installation</h3>
                    <p class="aboutp">Gravida dictum fusce ut placerat. auctor tincidunt aliquam sit amet cursus mauris</p>
                </div>
                <div class="col-sm-3 text-center">
                    <img class="abi" src="../webroot/img/About img/Suitable Machinery.webp" alt="">
                    <h3 class="abouth3">Suitable Machinery</h3>
                    <p class="aboutp">Eu nisl nunc mi ipsum faucibus auctor tincidunt aliquam sit amet cursus mauris</p>
                </div>
                <div class="col-sm-3 text-center">
                    <img class="abi" src="../webroot/img/About img/Quality Adhesives.webp" alt="">
                    <h3 class="abouth3">Quality Adhesives</h3>
                    <p class="aboutp">Viverra tellus in hac habitasse auctor tincidunt aliquam sit amet cursus mauris</p>
                </div>
            </div>
        </div>

