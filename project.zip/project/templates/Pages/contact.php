


    <div class="container py-5">
        <div class="row">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3720.753942002585!2d79.64966447503535!3d21.162188330520692!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a2b3f528f4d2749%3A0x711a70051026b7f2!2sJ.%20M.%20Patel%20College%20-Department%20of%20Management%20Science!5e0!3m2!1sen!2sin!4v1705239804668!5m2!1sen!2sin" width="100%" height="578" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </div>
    <div class="container py-5">
        <div class="row" style="column-gap: 83px;">
            <div id="Contact" class="col-md-3 text-center py-5">
                <i id="coni" class="bi bi-telephone-fill"></i><br><br>
                <h2>Phone</h2>
                <p class="info"><b>Call:</b>8446958335 <br>
                <b>Toll Free:</b>0000 0000 0000</p>
            </div>
            <div id="Contact" class="col-md-3 text-center py-5">
                <i id="coni" class="bi bi-envelope-fill"></i><br><br>
                <h2>Email</h2>
                <p class="info"><a href="#" style="text-decoration: none; color: rgb(46, 42, 42);">ayushmeshra155@gmail.com</a><br>
                <a href="#" style="text-decoration: none; color: rgb(46, 42, 42);">example@gmail.com</a></p>
            </div>
            <div id="Contact" class="col-md-3 text-center py-5">
                <i id="coni" class="bi bi-geo-alt-fill"></i><br><br>
                <h2>Address</h2>
                <p class="info">J.M. Patel Arts, Commerce & Science College, Bhandara.</p>
            </div>
        </div>
    </div>
    <!--from-->
    <div class="container py-5">
        <div class="col col-md-12">
            <h2 class="text-center" style="padding-top: 5px;">Contact From</h2>
        
            
            <div class="form-group row d-flex" style="justify-content: center; padding-top: 50px;">
                <div class="col-sm-8">
                  <input type="NAME" class="form-control py-3" style="box-shadow: 1px 1px 1px;" id="inputEmail3" placeholder="FULL NAME">
                </div>
                <div class="col-sm-8">
                    <input type="email" class="form-control py-3" style="box-shadow: 1px 1px 1px;" id="inputEmail3" placeholder="Email">
                  </div>
                  <div class="col-sm-8">
                    <input type="number" class="form-control py-3"style="box-shadow: 1px 1px 1px;" id="inputEmail3" placeholder="PHONE NUMBER">
                  </div>
                  <div class="col-sm-8">
                    <input type="message" class="form-control py-5" style="height: 150px; box-shadow: 1px 1px 1px;" id="inputEmail3" placeholder="MESSAGE">
                  </div>
                  <div class="col-sm-8 text-center">
                    <a href="#" style="text-decoration: none; color: rgb(46, 42, 42);"><button type="submit" class="conbtn"><b>SEND</b></button></a>
                  </div>
            </form>
        </div>
      </div>
    </div>
