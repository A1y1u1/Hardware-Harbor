<div class="untree_co-section">
  <div class="container py-5">
    <div class="row">
      <div class="col-md-12 text-center pt-5">
        <span class="display-3 thankyou-icon text-primary">
          <i class="bi bi-cart-check" style="color: #1C393D; font-size: larger;"></i>
        </span>
        <h2 class="display-3 text-black">Thank you!</h2>
        <p class="lead mb-5">You order was successfuly completed.</p>
        <p><a href="<?= $this->Url->build(['controller'=>'pages','action'=>'homepage']);?>" id="PlaceOrder" style="height: 46px; width: 186px; padding: 10px;" class="btn btn-sm btn-outline-black">Back to shop</a></p>
      </div>
    </div>
  </div>
</div>