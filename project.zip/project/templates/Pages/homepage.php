        
        
    
<section>

  <div class="swiper-container slideshow">

    <div class="swiper-wrapper">

      <div class="swiper-slide slide">
        <div class="slide-image" style="background-image: url(../img/Home1.jpg)"></div>
        <span class="slide-title">Sunny Tiles</span>
      </div>

      <div class="swiper-slide slide">
        <div class="slide-image" style="background-image: url(../img/Home2.jpg)"></div>
        <span class="slide-title">Garden Tiles</span>
      </div>

      <div class="swiper-slide slide">
        <div class="slide-image" style="background-image: url(../img/Home3.jpg)"></div>
        <span class="slide-title">Swimming Pool Tiles</span>
      </div>
    </div>

    <div class="slideshow-pagination"></div>

    <div class="slideshow-navigation">
      <div class="slideshow-navigation-button prev"><span class="fas fa-chevron-left"></span></div>
      <div class="slideshow-navigation-button next"><span class="fas fa-chevron-right"></span></div>
    </div>

  </div>

</section>
<script>
    // The Slideshow class.
class Slideshow {
    constructor(el) {
        
        this.DOM = {el: el};
      
        this.config = {
          slideshow: {
            delay: 3000,
            pagination: {
              duration: 3,
            }
          }
        };
        
        // Set the slideshow
        this.init();
      
    }
    init() {
      
      var self = this;
      
      // Charmed title
      this.DOM.slideTitle = this.DOM.el.querySelectorAll('.slide-title');
      this.DOM.slideTitle.forEach((slideTitle) => {
        charming(slideTitle);
      });
      
      // Set the slider
      this.slideshow = new Swiper (this.DOM.el, {
          
          loop: true,
          autoplay: {
            delay: this.config.slideshow.delay,
            disableOnInteraction: false,
          },
          speed: 500,
          preloadImages: true,
          updateOnImagesReady: true,
          
          // lazy: true,
          // preloadImages: false,

          pagination: {
            el: '.slideshow-pagination',
            clickable: true,
            bulletClass: 'slideshow-pagination-item',
            bulletActiveClass: 'active',
            clickableClass: 'slideshow-pagination-clickable',
            modifierClass: 'slideshow-pagination-',
            renderBullet: function (index, className) {
              
              var slideIndex = index,
                  number = (index <= 8) ? '0' + (slideIndex + 1) : (slideIndex + 1);
              
              var paginationItem = '<span class="slideshow-pagination-item">';
              paginationItem += '<span class="pagination-number">' + number + '</span>';
              paginationItem = (index <= 8) ? paginationItem + '<span class="pagination-separator"><span class="pagination-separator-loader"></span></span>' : paginationItem;
              paginationItem += '</span>';
            
              return paginationItem;
              
            },
          },

          // Navigation arrows
          navigation: {
            nextEl: '.slideshow-navigation-button.next',
            prevEl: '.slideshow-navigation-button.prev',
          },

          // And if we need scrollbar
          scrollbar: {
            el: '.swiper-scrollbar',
          },
        
          on: {
            init: function() {
              self.animate('next');
            },
          }
        
        });
      
        // Init/Bind events.
        this.initEvents();
        
    }
    initEvents() {
        
        this.slideshow.on('paginationUpdate', (swiper, paginationEl) => this.animatePagination(swiper, paginationEl));
        //this.slideshow.on('paginationRender', (swiper, paginationEl) => this.animatePagination());

        this.slideshow.on('slideNextTransitionStart', () => this.animate('next'));
        
        this.slideshow.on('slidePrevTransitionStart', () => this.animate('prev'));
            
    }
    animate(direction = 'next') {
      
        // Get the active slide
        this.DOM.activeSlide = this.DOM.el.querySelector('.swiper-slide-active'),
        this.DOM.activeSlideImg = this.DOM.activeSlide.querySelector('.slide-image'),
        this.DOM.activeSlideTitle = this.DOM.activeSlide.querySelector('.slide-title'),
        this.DOM.activeSlideTitleLetters = this.DOM.activeSlideTitle.querySelectorAll('span');
      
        // Reverse if prev  
        this.DOM.activeSlideTitleLetters = direction === "next" ? this.DOM.activeSlideTitleLetters : [].slice.call(this.DOM.activeSlideTitleLetters).reverse();
      
        // Get old slide
        this.DOM.oldSlide = direction === "next" ? this.DOM.el.querySelector('.swiper-slide-prev') : this.DOM.el.querySelector('.swiper-slide-next');
        if (this.DOM.oldSlide) {
          // Get parts
          this.DOM.oldSlideTitle = this.DOM.oldSlide.querySelector('.slide-title'),
          this.DOM.oldSlideTitleLetters = this.DOM.oldSlideTitle.querySelectorAll('span'); 
          // Animate
          this.DOM.oldSlideTitleLetters.forEach((letter,pos) => {
            TweenMax.to(letter, .3, {
              ease: Quart.easeIn,
              delay: (this.DOM.oldSlideTitleLetters.length-pos-1)*.04,
              y: '50%',
              opacity: 0
            });
          });
        }
      
        // Animate title
        this.DOM.activeSlideTitleLetters.forEach((letter,pos) => {
					TweenMax.to(letter, .6, {
						ease: Back.easeOut,
						delay: pos*.05,
						startAt: {y: '50%', opacity: 0},
						y: '0%',
						opacity: 1
					});
				});
      
        // Animate background
        TweenMax.to(this.DOM.activeSlideImg, 1.5, {
            ease: Expo.easeOut,
            startAt: {x: direction === 'next' ? 200 : -200},
            x: 0,
        });
      
        //this.animatePagination()
    
    }
    animatePagination(swiper, paginationEl) {
            
      // Animate pagination
      this.DOM.paginationItemsLoader = paginationEl.querySelectorAll('.pagination-separator-loader');
      this.DOM.activePaginationItem = paginationEl.querySelector('.slideshow-pagination-item.active');
      this.DOM.activePaginationItemLoader = this.DOM.activePaginationItem.querySelector('.pagination-separator-loader');
      
      console.log(swiper.pagination);
      // console.log(swiper.activeIndex);
      
      // Reset and animate
        TweenMax.set(this.DOM.paginationItemsLoader, {scaleX: 0});
        TweenMax.to(this.DOM.activePaginationItemLoader, this.config.slideshow.pagination.duration, {
          startAt: {scaleX: 0},
          scaleX: 1,
        });
      
      
    }
    
}

const slideshow = new Slideshow(document.querySelector('.slideshow'));

</script>
      <!--Slider-->





<div class="container-fluid">
  <div class="row">
    <div class="col-md-4">
       <div class="card">
          <img class="card-img-top" src="../webroot/img/Home Row.jpg" alt="Card image cap">
          <div class="card-body">
             <h5 class="card-title border-bottom pb-3">Tiles<a href="#" class="float-right d-inline-flex share"></a></h5>
             <p class="card-text text-white">Welcome to Hardware Harbor Tiles & More!. Where inspiration is abound. 
              Choose over thousands of designs inspired by nature. Choose 
              from different looks - wood, marble, vintage, textured, natural, 
              modern and more. Select your choice of tile finishes from glazed 
              to glossy, matte to rustic and much more. Welcome again, to the world of innovation!</p>
          </div>
       </div>
    </div>
    <div class="col-md-4">
       <div class="card">
          <img class="card-img-top" src="../webroot/img/Home Row1.jpg" alt="Card image cap">
          <div class="card-body">
             <h5 class="card-title border-bottom pb-3">Marbles<a href="#" class="float-right d-inline-flex share"></a></h5>
             <p class="card-text text-white">Bring home an exquisite piece of splendor! Explore world's best quality 
              marble sourced from the finest mines in Italy and around the globe. Enjoy 
              the uniqueness of materials such as marble, granite, onyx, and semi-precious 
              stones, transformed by NITCO into livable surfaces.</p>
          </div>
       </div>
    </div>
    <div class="col-md-4">
       <div class="card bg-light">
          <img class="card-img-top" src="../webroot/img/Home Row3.jpg" alt="Card image cap">
          <div class="card-body">
             <h5 class="card-title border-bottom pb-3">Hardware Tools<a href="#" class="float-right d-inline-flex share"></a></h5>
             <p class="card-text text-white">Shopper52 Special Combo Offer! 10mm Powerful Drill Machine 
              With 13Pcs Drill Bit Set And Hobby Tool Kit - DRL13BTHOB DRL13BTHOB Angle Drill  
              (10 mm Chuck Size)</p>
          </div>
       </div>
    </div>
  </div>
  
  </div>

<div class="container-fluid py-5 ">

  <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
    <div class="col">
      <a href="" style="color: black; text-decoration: none;">
      <div class="card shadow-sm" style="background-color: #1C393D; color: #A08442;">
        <img src="../webroot/img/Home Images/Bathrooms Tiles.jpg" alt="">
         <h2 style="text-align: center;">Bathrooms Tiles</h2>
      </div>
      </a>
    </div>
    <div class="col">
      <a href="" style="color: black; text-decoration: none;">
      <div class="card shadow-sm" style="background-color: #1C393D; color: #A08442;">
        <img src="../webroot/img/Home Images/Bedroom Tiles.jpg" alt="">
          <h2 style="text-align: center;">Bedroom Tiles</h2>
      </div>
      </a>
    </div>
    <div class="col">
      <a href="" style="color: black; text-decoration: none;">
      <div class="card shadow-sm" style="background-color: #1C393D; color: #A08442;">
        <img src="../webroot/img/Home Images/Kitchen Tiles.jpg" alt="">
          <h2 style="text-align: center;">Kitchen Tiles</h2>
      </div>
      </a>
    </div>
    <div class="col">
      <a href="" style="color: black; text-decoration: none;">
      <div class="card shadow-sm" style="background-color: #1C393D; color: #A08442;">
        <img src="../webroot/img/Home Images/Living Room Tiles.jpg" alt="">
        <h2 style="text-align: center;">Living Room Tiles</h2>
      </div>
      </a>
    </div>
    <div class="col">
      <a href="" style="color: black; text-decoration: none;">
      <div class="card shadow-sm" style="background-color: #1C393D; color: #A08442;">
        <img src="../webroot/img/Home Images/Marbles.jpg" alt="">
          <h2 style="text-align: center;">Marbles</h2>
      </div>
      </a>
    </div>
    <div class="col">
      <a href="" style="color: black; text-decoration: none;">
      <div class="card shadow-sm" style="background-color: #1C393D; color: #A08442;">
        <img src="../webroot/img/Home Images/Swimming Pool Tiles.jpg" alt="">
        <h2 style="text-align: center;">Swimming Pool Tiles</h2>
      </div>
      </a>
    </div>
  </div>
</div>
