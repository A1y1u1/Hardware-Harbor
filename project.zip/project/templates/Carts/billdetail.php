<div class="untree_co-section">
      <div class="container py-3">
        

        <div class="row">
          <div class="col-md-6 mb-5 mb-md-0">
            <h2 class="h3 mb-3 text-black">Billing Details</h2>
            <div class="p-3 p-lg-5 border bg-white">
              <fieldset>
 <?= $this->Form->create(null, [ 'url' => ['controller' => 'Usertables', 'action' => 'Submit' ]]); ?>
 
       
  
 <div class="form-group">
                <label for="c_country" class="text-black">
                <?=$this->Form->control('country');?> 
                  <span class="text-danger">*</span>
                </label>
                <select id="c_country" class="form-control">
                  <option value="1">Select a country</option>    
                  <option value="2">bangladesh</option>    
                  <option value="3">Algeria</option>    
                  <option value="4">Afghanistan</option>    
                  <option value="5">Ghana</option>    
                  <option value="6">Albania</option>    
                  <option value="7">Bahrain</option>    
                  <option value="8">Colombia</option>     
                  <option value="10">India</option>    
                </select>
              <!-- <?php echo $this->Form->label('c_country', '<span class="text-danger">*</span> Country', ['class' => 'text-black']);

                  echo $this->Form->select('c_country', [
                      '1' => 'Select a country',
                      '2' => 'Bangladesh',
                      '3' => 'Algeria',
                      '4' => 'Afghanistan',
                      '5' => 'Ghana',
                      '6' => 'Albania',
                      '7' => 'Bahrain',
                      '8' => 'Colombia',
                      '10' => 'India'
                  ], [
                      'class' => 'form-control',
                      'id' => 'c_country'
                  ]); ?> -->

              </div>
              <div class="form-group row">

                <div class="col-md-6">
                  <label for="c_lname" class="text-black"> <?=$this->Form->control('firstname');?><span class="text-danger">*</span></label>
                  <!--<input type="text" class="form-control" required id="c_lname" name="c_lname"> -->
                  <!-- <?php echo $this->Form->label('firstname', 'First Name', ['class' => 'text-black']);

                      echo $this->Form->text('firstname', [
                      'class' => 'form-control',
                      'required' => true, // Adding 'required' attribute for validation
                      'id' => 'c_lname'
                  ]); ?> -->
                </div>

                <div class="col-md-6">
                  <!-- <label for="c_lname" class="text-black"><span class="text-danger">*</span></label>
                  <input type="text" class="form-control" required id="c_lname" name="c_lname"> -->
                <?php echo $this->Form->label('lastname', 'Last Name', ['class' => 'text-black']);

                      echo $this->Form->text('lastname', [
                      'class' => 'form-control',
                      'required' => true, // Adding 'required' attribute for validation
                      'id' => 'c_lname'
                ]); ?>
                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <!-- <label for="c_companyname" class="text-black"></label>
                  <input type="text" class="form-control" required id="c_companyname" name="c_companyname"> -->
                <?php echo $this->Form->label('companyname', 'Company Name', ['class' => 'text-black']);

                      echo $this->Form->text('companyname', [
                      'class' => 'form-control',
                      'required' => true, // Adding 'required' attribute for validation
                      'id' => 'c_companyname'
                ]); ?>

                </div>
              </div>

              <div class="form-group row">
                <div class="col-md-12">
                  <!-- <label for="c_address" class="text-black"><span class="text-danger">*</span></label>
                  <input type="text" class="form-control" required id="c_address" name="c_address" placeholder="Street address"> -->
                <?php echo $this->Form->label('address', 'Address', ['class' => 'text-black']);

                      echo $this->Form->text('address', [
                      'class' => 'form-control',
                      'required' => true, // Adding 'required' attribute for validation
                      'placeholder' => 'Street address',
                      'id' => 'c_address'
                ]); ?>
                </div> 
              </div>

              <div class="form-group mt-3">
                <!-- <input type="text" class="form-control" required placeholder="Apartment, suite, unit etc. (optional)"> -->
                <?php echo $this->Form->text('address', [
                      'class' => 'form-control',
                      'required' => true, // Adding 'required' attribute for validation
                      'placeholder' => 'Apartment, suite, unit etc. (optional)'
                ]); ?>
              </div>

              <div class="form-group row">
                <div class="col-md-6">
                  <!-- <label for="c_state_country" class="text-black"><?= $this->Form->control('state');?> <span class="text-danger">*</span></label>
                  <input type="text" class="form-control" required id="c_state_country" name="c_state_country"> -->
                  <?php echo $this->Form->label('state', 'State', ['class' => 'text-black']);

                      echo $this->Form->text('post', [
                      'class' => 'form-control',
                      'required' => true, // Adding 'required' attribute for validation
                      'id' => 'c_postal_zip'
                      ]); ?>
                </div>
                <div class="col-md-6">
                  <!-- <label for="c_postal_zip" class="text-black"><?= $this->Form->control('post');?><span class="text-danger">*</span></label>
                  <input type="text" class="form-control" required id="c_postal_zip" name="c_postal_zip"> -->
                <?php echo $this->Form->label('post', 'Pin Code', ['class' => 'text-black']);

                      echo $this->Form->text('post', [
                      'class' => 'form-control',
                      'required' => true, // Adding 'required' attribute for validation
                      'id' => 'c_postal_zip'
                      ]); ?>
                </div>
              </div>

              <div class="form-group row mb-5">
                <div class="col-md-6">
                  <!-- <label for="c_email_address" class="text-black"><span class="text-danger">*</span></label>
                  <input type="email" class="form-control" required id="c_email_address" name="c_email_address" placeholder="Email"> -->
                <?php echo $this->Form->label('email', 'Email', ['class' => 'text-black']);

                      echo $this->Form->email('email', [
                      'class' => 'form-control',
                      'placeholder' => 'Email',
                      'required' => true, // Adding 'required' attribute for validation
                      'id' => 'c_email_address'
                ]);?>
                </div>
                <div class="col-md-6">
                  <!-- <label for="c_phone" class="text-black"><?=$this->Form->control('phonenumber'); ?><span class="text-danger">*</span></label>
                  <input type="text" class="form-control" id="c_phone" name="c_phone" placeholder="Phone Number"> -->
                <?php echo $this->Form->label('phonenumber', 'Phone Number', ['class' => 'text-black']);

                      echo $this->Form->text('phonenumber', [
                      'class' => 'form-control',
                      'placeholder' => 'Phone Number',
                      'id' => 'c_phone'
                ]); ?>
                </div>
              </div>
              
              <div class="text-center">
                <?=$this->form->button('Submit',[
        'id' => 'PlaceOrder',
        'class' => ['btn', 'btn-black', 'btn-lg', 'py-3', 'btn-block']])?>
              </div>
              <?=$this->form->end()?>
             </fieldset>
              </div>
</div>



<div class="col-md-6">

<div class="row mb-5">
  <div class="col-md-12">
    <h2 class="h3 mb-3 text-black">Your Order</h2>
    <div class="p-3 p-lg-5 border bg-white">
      <table class="table site-block-order-table mb-5">
        <thead>
          <th>Product</th>
          <th>Qty</th>
          <th>Total</th>
        </thead>
        <tbody>

       <?php $sum = 0; 
        foreach ($carts as $cart)
{ ?>
  <tr>
            <td><?php echo $cart->product->proname; ?></td>
            <td><strong class="mx-2"><?= $this->Number->format($cart->quantity) ?></strong> </td>
            <td><?= h($cart->total) ?></td>
          </tr>

<?php 
$total= $cart->total;
 
$sum = $sum +$total;

} ?>
          
          <tr>
            <td class="text-black font-weight-bold"><strong>Order Total</strong></td>
            <td></td>
            <td class="text-black font-weight-bold"><strong><?php echo $sum ?></strong></td>
          </tr>
        </tbody>
      </table>

      <div class="border p-3 mb-3">
        <h3 class="h6 mb-0"><input type="checkbox">  Cash On Delivery</h3>
      </div>

      <div class="form-group">
      <?php
        //echo $this->Html->tag('button', 'Place Order', [
        //'id' => 'PlaceOrder',
        //'class' => ['btn', 'btn-black', 'btn-lg', 'py-3', 'btn-block'],
        //'onclick' => 'window.location.href="' . $this->Url->build(['controller' => 'pages', 'action' => 'thankyou']) . '"'
        //]);
      ?>

      </div>

    </div>
  </div>
</div>

</div>
</div>
<!-- </form> -->
</div>
</div>
