<style>
  delete-link{
    
}
</style>

<div class="untree_co-section before-footer-section">
  <div class="container py-3">
    <div class="row mb-5">
      <form class="col-md-12" method="post">
        <div class="site-blocks-table">
          <table class="table">
            <thead>

           
            <!-- <tr>
               
                <td></td>
                 Add other product-related data as needed 
            </tr> -->
     
              <tr>
                <th class="product">Image</th>
                <th class="product">Product</th>
                <th class="product">Price</th>
                <th class="product">Quantity</th>
                <th class="product">Total</th>
                <th class="product">Remove</th>
              </tr>
            </thead>
            <tbody>
              <tr>
              <?php 
               $sum=0;
          foreach ($carts as $cart)
            {
              ?> 
                <td class="product-thumbnail">
                  <img src="../webroot/img/<?= $cart->product->subtype ?>/<?= $cart->product->descriptionimage?>" height="150px" width="200px" alt="Image">
                  <!-- <h3><?= h($cart->product->proname) ?></h3> </td> -->
                </td>



                <?php echo $this->Form->create(null, [
    'url' => [
        'controller' => 'usertable',
        'action' => 'billadd'
    ]
]); ?>


                <td class="product-name">
                  <h2 class="h5 text-black"><?= h($cart->product->proname) ?><br><?= h($cart->product->description) ?></h2>
                </td>
                <td><?= h($cart->product->perbox) ?></td>
                <?php
      
       ?>

                <td>
                <?php if (isset($cart) && $cart->quantity): ?>
                  <div class="input-group mb-3 d-flex align-items-center quantity-container justify-content-end" style="max-width: 120px;">
                  <p><?= $this->Number->format($cart->quantity) ?></p>
                  </div><?php endif; ?>

                </td>
                <td>
                <?php if (isset($cart) && $cart->total): ?>
                <p><?= h($cart->total) ?></p><?php endif; ?></td> 
                
                <td>
  <?= $this->Form->create(null, [
    'url' => ['controller' => 'Carts', 'action' => 'delete', $cart->id],
    'confirm' => __('Are you sure you want to delete #{0}?', $cart->id),
  ]) ?>

<?php echo $this->Html->link(
    __('X'),
    ['controller' => 'Carts', 'action' => 'delete', $cart->id],
    ['confirm' => __('Are you sure you want to delete #{0}?', $cart->id), 'style' => 'color: black;', 'id' => 'close-button-'.$cart->id]
); ?>

  <?= $this->Form->end() ?>
</td>

              </tr>

              <tr>
              <?php $total= $cart->total;
             
             $sum = $sum +$total;
             
         } ?>
                
            </tbody>
          </table>
        </div>
              
    </div>

    <div class="row">
      <div class="col-md-6">
        <div class="row mb-5">
          <div class="col-md-6">
            <button class="btn btn-outline-black btn-sm btn-block" id="PlaceOrder" style="height: 60px; font-size: 18px;" onclick="window.location='<?= $this->Url->build(['controller'=>'pages','action'=>'homepage']);?>'">Back to Home</button>
          </div>
        </div>
      </div>
      <div class="col-md-6 pl-5">
        <div class="row justify-content-end">
          <div class="col-md-7">
            <div class="row">
              <div class="col-md-12 text-right border-bottom mb-5">
                <h3 class="text-black h4 text-uppercase">Cart Totals</h3>
              </div>
            </div>
           
            <div class="row mb-5">
              <div class="col-md-6">
                <span class="text-black">Total</span>
              </div>
              <div class="col-md-6 text-right">
                <strong class="text-black"><?php echo $sum; ?></strong>
              </div>
            </div>

            <div class="row">
              <div class="col-md-12">
            
              <?php
echo $this->Html->tag('button', 'Proceed To Checkout', [
    'id' => 'PlaceOrder',
    'class' => ['btn', 'btn-black', 'btn-lg', 'py-3', 'btn-block'],
    'onclick' => 'window.location.href="' . $this->Url->build(['controller' => 'Carts', 'action' => 'billdetail']) . '"'
]);
?>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>