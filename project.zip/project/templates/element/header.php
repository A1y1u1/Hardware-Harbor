
  
    <header>
      <nav class="navbar" style="background-color: #E5E1DA">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            <!-- <img src="../webroot/img/Icon/Icon1.png" width="230px" height="150px"> -->
    <?= $this->Html->image('Icon/Icon1.png' , [array('style'=>'width="230px" height="150px"')]);?>


          </a>
            <div class="d-flex">
              <a class="header-incon" href="Login.html"><i id="header-incons" class="bi bi-person"></i></a>
              <a class="header-incon" href="<?= $this->Url->build(['controller'=>'carts','action'=>'cartdetail',]);?>"><i id="header-incons" class="bi bi-cart4"></i></a>
            </div>
        </div>
      </nav>

      <!-- Menu Bar-->
      <nav class="navbar navbar-expand-lg navbar-dark" style="background-color: #1C393D;">
        <div class="container-fluid px-5">
          <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
              <li class="nav-item">
                <a class="nav-link active mx-1" aria-current="page" href="<?= $this->Url->build(['controller'=>'pages','action'=>'homepage']);?>" style="font-size: 15px;"><b>Home</b></a>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle mx-1" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
                  aria-expanded="false" style="font-size: 15px;">
                  <b>Tiles By Spaces</b>
                </a>
                <div class="dropdown-menu" id="ayush" aria-labelledby="navbarDropdown">
                  <ul>
                    <li><a class="dropdown-item" >Bathroom Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Bathroom Wall Tiles']]);?>">Bathroom Wall Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Bathroom Floor Tiles']]);?>">Bathroom Floor Tiles</a></li>
                  </ul>
                  <ul>
                    <li><a class="dropdown-item" >Living Room Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Living Room Wall Tiles']]);?>">Living Room Wall Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Living Room Floor Tiles']]);?>">Living Room Floor Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Living Room Wooden Tiles']]);?>">Living Room Wooden Tiles</a></li>
                  </ul>
                  <ul>
                    <li><a class="dropdown-item" >Kitchen Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Kitchen Wall Tiles']]);?>">Kitchen Wall Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Kitchen Floor Tiles']]);?>">Kitchen Floor Tiles</a></li>
                  </ul>
                  <ul>
                    <li><a class="dropdown-item" >Bedroom Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Bedroom Floor Tiles']]);?>">Bedroom Floor Tiles</a></li>
                  </ul>
                  <ul>
                    <li><a class="dropdown-item" >Office Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Office Floor Tiles']]);?>">Office Floor Tiles</a></li>
                  </ul>
                  <ul>
                    <li><a class="dropdown-item" >Outdoor Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Garden Tiles']]);?>">Garden Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Parking Tiles']]);?>">Parking Tiles</a></li>
                    <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Swimming Pool Tiles']]);?>">Swimming Pool Tiles</a></li>
                  </ul>
                </div>
              </li>
              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle mx-1" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
                aria-expanded="false" style="font-size: 15px;">
                <b>Marbles</b>
              </a>
              <div class="dropdown-menu" id="ayush" aria-labelledby="navbarDropdown">
                <ul>
                  <li><a class="dropdown-item" >Colors Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'White Marbles']]);?>">White Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Black Marbles']]);?>">Black Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Blue Marbles']]);?>">Blue Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Beige Marbles']]);?>">Beige Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Red Marbles']]);?>">Red Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Brown Marbles']]);?>">Brown Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Pink Marbles']]);?>">Pink Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Grey Marbles']]);?>">Grey Marbles</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Green Marbles']]);?>">Green Marbles</a></li>
                </ul>
              </div>
              </li>

              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle mx-1" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown"
                aria-expanded="false" style="font-size: 15px;">
                <b>Bathroom Accessories</b>
              </a>
              <div class="dropdown-menu" id="ayush" aria-labelledby="navbarDropdown">
                <ul>
                  <li><a class="dropdown-item" >Accessories</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Auxiliaries']]);?>">Auxiliaries</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Bath Tub']]);?>">Bath Tub</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Taps']]);?>">Taps</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Shower']]);?>">Shower</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Towel Rack']]);?>">Towel Rack</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Urinal']]);?>">Urinal</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Wash Besin']]);?>">Wash Besin</a></li>
                  <li><a class="dropdown-item" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Western commode & Cisterns']]);?>">Western commode & Cisterns</a></li>
                </ul>
              </div>
              </li>
              <li class="nav-item" >
                <a class="nav-link  text-white mx-1" style="font-size: 15px; " aria-current="page" href="<?= $this->Url->build(['controller'=>'product','action'=>'allpro', '?' => ['param1' => 'Hardware Tools']]);?>"><b>Hardware Tools</b></a>
              </li>
              <li class="nav-item" >
                <a class="nav-link  text-white mx-1" style="font-size: 15px;" aria-current="page" href="<?= $this->Url->build(['controller'=>'pages','action'=>'about']);?>"><b>About</b></a>
              </li>
              <li class="nav-item" >
                <a class="nav-link  text-white mx-1" style="font-size: 15px;" aria-current="page" href="<?= $this->Url->build(['controller'=>'pages','action'=>'contact']);?>"><b>Contact Us</b></a>
              </li>
            </ul>
          </div>
        </div>
      </nav>
</header>
