<body>

<!-- Footer -->
<div class="Footer" style="background-color: #1C393D; padding-top: 10px;">
  <div class="container">
    <div class="row">
      <div class="col-md-3 mt-3">
        <span style="color: #A08442; font-size: 18px; "><b>WELCOME TO HAEDWARE HARBOR</b></span>
        <p style="color: white;">The most trusted online platform, with all type of Tiles, Marbal & Hardware product,
          we can provide genuine product selling a premium price. All type of product are branded. Which is made in india.
          All Tiles, Marbal & Hardware products with Garenty and Warranty. 
        </p>
      </div>
      <div class="col-md-3 mt-3">
        <span style="color: #A08442; font-size: 18px; "><b>CUSTOMER SERVICES</b></span><br>
        <div>
          <a class="text-decoration-none" style="color: white" href=" ">Free Shipping</a><br>
          <a class="text-decoration-none" style="color: white" href=" ">Privacy policy</a><br>
          <a class="text-decoration-none" style="color: white" href=" ">Return & Exchange policy</a><br>
          <a class="text-decoration-none" style="color: white" href=" ">Return Order</a><br>
          <a class="text-decoration-none" style="color: white" href=" ">Term & Condition</a><br>
        </div>
      </div>
      <div class="col-md-4 mt-3">
        <span style="color: #A08442; font-size: 18px;"><b>CONTACT INFO</b></span><br>
        <div class="contact" style="color: white;">
          <i class="bi bi-geo-alt-fill"></i> Bhandara. 441904<br>
          <i class="bi bi-telephone"></i> +91 8446958335<br>
          <i class="bi bi-envelope"></i> Hardwareharbor@gmail.com
        </div>

        <div class="sub mt-4">
          <span style="color:#A08442; font-size: 18px;"><b>Subcribe</b></span><br>
          <form class="row g-3">
            <div class="col-auto">
              <label for="inputPassword2" class="visually-hidden">Email</label>
              <input type="text" class="form-control" id="inputPassword2" placeholder="Email">
            </div>
            <div class="col-auto">
              <button type="submit" class="Send"><b>Send</b></button>
            </div>
          </form>
        </div>

      </div>
      <div class="col-md-2 mt-3">
        <span style="color: #A08442; font-size: 18px; margin-bottom: 20pxs;"><b>QUICK LINK</b></span>
        <div>
          <a class="text-decoration-none" style="color: white" href=" ">Home</a><br>
          <a class="text-decoration-none" style="color: white" href="About.html">About us</a><br>
          <a class="text-decoration-none" style="color: white" href="Contact.html">Contact us</a><br>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="Footer" style="background-color: #1C393D; width: 100%;">
  <div class="container">
    <p style="text-align: center; color: white; padding: 15px; margin-bottom: 0px; font-size: 20px;" >© 2024 Only Hardware Harbor Tiles, Marbles & More! by India</p>
  </div>
</div>
<!-- Footer End -->
  </body>
