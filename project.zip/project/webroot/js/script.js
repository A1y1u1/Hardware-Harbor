// The same as the previous, but infinite
